# Single-Multiple-Custom-Object-Detection-and-Tracking

Please visit https://www.youtube.com/watch?v=zi-62z-3c4U for the full course - Real-time Multiple Object Tracking (MOT) with Yolov3, Tensorflow and Deep SORT
